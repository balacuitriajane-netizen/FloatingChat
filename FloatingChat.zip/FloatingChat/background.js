// background.js — Screenshot handler
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "takeScreenshot") {
    chrome.tabs.captureVisibleTab(
      sender.tab.windowId,
      { format: "png" },
      (dataUrl) => {
        sendResponse({ success: true, dataUrl });
      }
    );
    return true; // Keep channel open for async response
  }
});