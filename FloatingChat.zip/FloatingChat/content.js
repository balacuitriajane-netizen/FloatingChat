(function () {
  if (document.getElementById("fc-floating-btn")) return;

  // === State Management with Local Storage ===
  const STORAGE_KEYS = {
    NOTES: "fc_notes",
    REMINDERS: "fc_reminders",
    TASKS: "fc_tasks",
    PASSWORDS: "fc_passwords"
  };

  const STATE = {
    isOpen: false,
    activeTab: "chat",
    messages: [],
    groups: [
      { id: 1, name: "Team Alpha", members: 5, unread: 2 },
      { id: 2, name: "Project Dev", members: 8, unread: 0 },
      { id: 3, name: "General Chat", members: 24, unread: 5 }
    ],
    media: [
      { id: 1, name: "Project_Brief.pdf", type: "pdf", size: "2.4 MB" },
      { id: 2, name: "Design_Mockup.png", type: "image", size: "1.1 MB" },
      { id: 3, name: "Demo_Video.mp4", type: "video", size: "18 MB" },
      { id: 4, name: "Meeting_Notes.docx", type: "doc", size: "85 KB" }
    ],
    shares: [
      { id: 1, title: "Dashboard Pro", url: "#", time: "2 hours ago" },
      { id: 2, title: "Figma Design Kit", url: "#", time: "1 day ago" },
      { id: 3, title: "API Documentation", url: "#", time: "3 days ago" }
    ],
    // Load from localStorage
    notes: JSON.parse(localStorage.getItem(STORAGE_KEYS.NOTES) || "[]"),
    reminders: JSON.parse(localStorage.getItem(STORAGE_KEYS.REMINDERS) || "[]"),
    tasks: JSON.parse(localStorage.getItem(STORAGE_KEYS.TASKS) || "[]"),
    passwords: JSON.parse(localStorage.getItem(STORAGE_KEYS.PASSWORDS) || "[]")
  };

  // === Save Helpers ===
  function saveData(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
  }

  // === YouTube & Link Detection ===
  function getYouTubeId(url) {
    const match = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    return match ? match[1] : null;
  }

  function linkify(text) {
    let escaped = text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
    const urlRegex = /((?:https?:\/\/|www\.)[^\s<>"]+[^\s.,;:!?)>])/gi;
    return escaped.replace(urlRegex, (url) => {
      const href = url.toLowerCase().startsWith("www.") ? "http://" + url : url;
      const ytId = getYouTubeId(href);
      if (ytId) {
        return `<div class="fc-link-preview fc-youtube-preview"><a href="${href}" target="_blank" rel="noopener noreferrer"><img src="https://img.youtube.com/vi/${ytId}/hqdefault.jpg" alt="YouTube Preview" loading="lazy" /><div class="fc-play-button">▶</div><div class="fc-preview-info"><span class="fc-preview-title">YouTube Video</span><span class="fc-preview-link">${url}</span></div></a></div>`;
      }
      if (/\.(jpg|jpeg|png|gif|webp|bmp|svg)(\?.*)?$/i.test(href)) {
        return `<div class="fc-link-preview fc-image-preview"><a href="${href}" target="_blank" rel="noopener noreferrer"><img src="${href}" alt="Image Preview" loading="lazy" onerror="this.parentElement.parentElement.style.display='none'"/><div class="fc-preview-info"><span class="fc-preview-title">📷 Image</span><span class="fc-preview-link">${url}</span></div></a></div>`;
      }
      return `<a href="${href}" target="_blank" rel="noopener noreferrer" class="fc-chat-link">${url}</a>`;
    });
  }

  // === Floating Button & Chatbox HTML ===
  const btn = document.createElement("button");
  btn.id = "fc-floating-btn";
  btn.setAttribute("aria-label", "Open chat");
  btn.innerHTML = `<span class="fc-btn-icon">💬</span><span class="fc-btn-status-dot"></span>`;
  document.body.appendChild(btn);

  const chatbox = document.createElement("div");
  chatbox.id = "fc-chatbox";
  chatbox.style.display = "none";
  chatbox.innerHTML = `
    <div class="fc-chat-window">
      <div class="fc-header">
        <div class="fc-header-left">
          <div class="fc-avatar">⚡</div>
          <div class="fc-header-text"><h3>Chat Everywhere</h3><p class="fc-status-indicator"><span class="fc-dot"></span><span>Online — Ready</span></p></div>
        </div>
        <button id="fc-close" class="fc-close-btn" aria-label="Close">✕</button>
      </div>
      <nav class="fc-tabs-nav">
        <button class="fc-tab-link active" data-tab="chat"><span class="fc-tab-icon">💬</span><span class="fc-tab-label">Chat</span></button>
        <button class="fc-tab-link" data-tab="media"><span class="fc-tab-icon">📁</span><span class="fc-tab-label">Media</span></button>
        <button class="fc-tab-link" data-tab="groups"><span class="fc-tab-icon">👥</span><span class="fc-tab-label">Groups</span></button>
        <button class="fc-tab-link" data-tab="tools"><span class="fc-tab-icon">🛠️</span><span class="fc-tab-label">Tools</span></button>
      </nav>
      <div class="fc-tabs-content">
        <!-- CHAT PANEL -->
        <section class="fc-tab-panel active" id="fc-panel-chat">
          <div class="fc-messages-area" id="fc-messages">
            <div class="fc-welcome-state"><div class="fc-welcome-icon-wrapper">👋</div><h4>Welcome back!</h4><p>Go to Tools tab to use all features!</p></div>
          </div>
          <div class="fc-input-container">
            <button class="fc-attach-btn" title="Attach file">📎</button>
            <input type="text" id="fc-input" class="fc-input" placeholder="Type message..." autocomplete="off" />
            <button id="fc-send" class="fc-send-btn">➤</button>
          </div>
        </section>

        <!-- MEDIA PANEL -->
        <section class="fc-tab-panel" id="fc-panel-media">
          <div class="fc-panel-scroll">
            <div class="fc-section-header"><h4>📎 Shared Media</h4><span class="fc-count-badge" id="media-count">0</span></div>
            <div class="fc-media-grid" id="fc-media-list"></div>
          </div>
        </section>

        <!-- GROUPS PANEL -->
        <section class="fc-tab-panel" id="fc-panel-groups">
          <div class="fc-panel-scroll">
            <div class="fc-section-header"><h4>👥 Groups</h4><span class="fc-count-badge">${STATE.groups.length}</span></div>
            <div class="fc-groups-list" id="fc-groups-list"></div>
            <button class="fc-primary-btn" style="margin-top:16px;"><span>+</span> Create New Group</button>
          </div>
        </section>

        <!-- TOOLS PANEL -->
        <section class="fc-tab-panel" id="fc-panel-tools">
          <div class="fc-panel-scroll">
            <!-- QUICK NOTES -->
            <div class="fc-tool-section">
              <h4 class="fc-tool-heading">📝 Quick Notes</h4>
              <div class="fc-tool-input-row">
                <input type="text" id="note-input" class="fc-input" placeholder="Write a note..." />
                <button id="note-save" class="fc-primary-btn">Save</button>
              </div>
              <div id="notes-list" class="fc-list-container"></div>
            </div>

            <!-- REMINDERS -->
            <div class="fc-tool-section">
              <h4 class="fc-tool-heading">⏰ Reminders</h4>
              <div class="fc-tool-input-row">
                <input type="text" id="remind-text" class="fc-input" placeholder="What to remember..." />
                <input type="datetime-local" id="remind-time" class="fc-input" style="max-width:180px;" />
                <button id="remind-save" class="fc-primary-btn">Set</button>
              </div>
              <div id="reminders-list" class="fc-list-container"></div>
            </div>

            <!-- TASK LIST -->
            <div class="fc-tool-section">
              <h4 class="fc-tool-heading">✅ Tasks</h4>
              <div class="fc-tool-input-row">
                <input type="text" id="task-input" class="fc-input" placeholder="New task..." />
                <button id="task-save" class="fc-primary-btn">Add</button>
              </div>
              <div id="tasks-list" class="fc-list-container"></div>
            </div>

            <!-- SEARCH -->
            <div class="fc-tool-section">
              <h4 class="fc-tool-heading">🔍 Search</h4>
              <div class="fc-tool-input-row">
                <input type="text" id="search-input" class="fc-input" placeholder="Search web..." />
                <select id="search-engine" class="fc-input" style="max-width:120px;">
                  <option value="google">Google</option>
                  <option value="bing">Bing</option>
                  <option value="duckduckgo">DuckDuckGo</option>
                </select>
                <button id="search-go" class="fc-primary-btn">Go</button>
              </div>
            </div>

            <!-- SCREENSHOT -->
            <div class="fc-tool-section">
              <h4 class="fc-tool-heading">📸 Screenshot</h4>
              <button id="screenshot-btn" class="fc-primary-btn" style="width:100%;">📷 Capture Visible Area</button>
              <p id="screenshot-status" style="margin-top:8px; font-size:12px; color:#6B7280;"></p>
            </div>

            <!-- PASSWORD MANAGER -->
            <div class="fc-tool-section">
              <h4 class="fc-tool-heading">🔐 Passwords</h4>
              <div class="fc-tool-input-row">
                <input type="text" id="pw-name" class="fc-input" placeholder="Site/Name" />
                <input type="password" id="pw-value" class="fc-input" placeholder="Password" />
              </div>
              <button id="pw-save" class="fc-primary-btn">Save Password</button>
              <div id="pw-list" class="fc-list-container"></div>
            </div>
          </div>
        </section>
      </div>
    </div>
  `;
  document.body.appendChild(chatbox);

  // === DOM Helpers ===
  const $ = sel => document.querySelector(sel);
  const $$ = sel => document.querySelectorAll(sel);

  // === RENDER FUNCTIONS ===
  function renderNotes() {
    const container = $("#notes-list");
    container.innerHTML = STATE.notes.map((n, i) => `
      <div class="fc-item-card">
        <span class="fc-item-text">${n.text}</span>
        <span class="fc-item-meta">${new Date(n.created).toLocaleString()}</span>
        <button class="fc-delete-btn" data-note="${i}">✕</button>
      </div>
    `).reverse().join("");
  }

  function renderReminders() {
    const container = $("#reminders-list");
    const now = Date.now();
    container.innerHTML = STATE.reminders.map((r, i) => {
      const isPast = new Date(r.time).getTime() < now;
      return `
        <div class="fc-item-card ${isPast ? "fc-past" : ""}">
          <span class="fc-item-text">${r.text}</span>
          <span class="fc-item-meta">${new Date(r.time).toLocaleString()}</span>
          <button class="fc-delete-btn" data-remind="${i}">✕</button>
        </div>
      `;
    }).reverse().join("");
  }

  function renderTasks() {
    const container = $("#tasks-list");
    container.innerHTML = STATE.tasks.map((t, i) => `
      <div class="fc-item-card ${t.done ? "fc-done" : ""}">
        <input type="checkbox" class="fc-task-check" data-task="${i}" ${t.done ? "checked" : ""} />
        <span class="fc-item-text">${t.text}</span>
        <button class="fc-delete-btn" data-task="${i}">✕</button>
      </div>
    `).reverse().join("");
  }

  function renderPasswords() {
    const container = $("#pw-list");
    container.innerHTML = STATE.passwords.map((p, i) => `
      <div class="fc-item-card">
        <span class="fc-item-text">${p.name}</span>
        <span class="fc-item-action" data-pw="${i}">👁️ Show</span>
        <button class="fc-delete-btn" data-pw-del="${i}">✕</button>
      </div>
    `).reverse().join("");
  }

  function renderMedia() {
    const container = $("#fc-media-list");
    $("#media-count").textContent = STATE.media.length;
    container.innerHTML = STATE.media.map(f => {
      const icon = { image: "🖼️", video: "🎬", pdf: "📕", doc: "📄" }[f.type] || "📄";
      return `<div class="fc-media-card"><div class="fc-media-icon-bg">${icon}</div><div class="fc-media-meta"><div class="fc-media-name">${f.name}</div><div class="fc-media-size">${f.size}</div></div></div>`;
    }).join("");
  }

  function renderGroups() {
    const container = $("#fc-groups-list");
    container.innerHTML = STATE.groups.map(g => `
      <div class="fc-group-card">
        <div class="fc-group-avatar">${g.name.charAt(0)}</div>
        <div class="fc-group-info">
          <div class="fc-group-name">${g.name}</div>
          <div class="fc-group-members">${g.members} members</div>
        </div>
        ${g.unread > 0 ? `<span class="fc-unread-badge">${g.unread}</span>` : ""}
      </div>
    `).join("");
  }

  // === CHAT ===
  function addMessage(text, sender = "bot") {
    const welcome = $("#fc-messages .fc-welcome-state");
    if (welcome) welcome.remove();
    const msg = document.createElement("div");
    msg.className = `fc-message fc-${sender}`;
    msg.innerHTML = `
      <div class="fc-bubble">${linkify(text)}</div>
      <div class="fc-message-footer">
        <span class="fc-time">${new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})}</span>
      </div>
    `;
    $("#fc-messages").appendChild(msg);
    $("#fc-messages").scrollTop = $("#fc-messages").scrollHeight;
    STATE.messages.push({ text, sender, time: Date.now() });
  }

  // === TAB SWITCHING ===
  function switchTab(tabName) {
    STATE.activeTab = tabName;
    $$(".fc-tab-link").forEach(l => l.classList.toggle("active", l.dataset.tab === tabName));
    $$(".fc-tab-panel").forEach(p => p.classList.toggle("active", p.id === `fc-panel-${tabName}`));
    
    if (tabName === "media") renderMedia();
    if (tabName === "groups") renderGroups();
    if (tabName === "tools") { renderNotes(); renderReminders(); renderTasks(); renderPasswords(); }
  }

  function toggleChat() {
    STATE.isOpen = !STATE.isOpen;
    chatbox.style.display = STATE.isOpen ? "block" : "none";
  }

  // === EVENT BINDING ===
  $("#fc-floating-btn").addEventListener("click", toggleChat);
  $("#fc-close").addEventListener("click", () => { chatbox.style.display = "none"; STATE.isOpen = false; });
  $$(".fc-tab-link").forEach(t => t.addEventListener("click", () => switchTab(t.dataset.tab)));
  $("#fc-send").addEventListener("click", () => {
    const val = $("#fc-input").value.trim();
    if (!val) return;
    addMessage(val, "user");
    $("#fc-input").value = "";
    setTimeout(() => addMessage("I'm your assistant — use the Tools tab to manage notes, tasks, reminders & more! 🛠️"), 700);
  });
  $("#fc-input").addEventListener("keydown", e => e.key === "Enter" && $("#fc-send").click());

  // === ALL TOOLS FUNCTIONALITY ===

  // 1. NOTES
  $("#note-save").addEventListener("click", () => {
    const text = $("#note-input").value.trim();
    if (!text) return;
    STATE.notes.push({ text, created: new Date().toISOString() });
    saveData(STORAGE_KEYS.NOTES, STATE.notes);
    $("#note-input").value = "";
    renderNotes();
    addMessage("📝 Note saved!", "bot");
  });
  document.addEventListener("click", e => {
    if (e.target.dataset.note !== undefined) {
      STATE.notes.splice(parseInt(e.target.dataset.note), 1);
      saveData(STORAGE_KEYS.NOTES, STATE.notes);
      renderNotes();
      addMessage("🗑️ Note deleted", "bot");
    }
  });

  // 2. REMINDERS
  $("#remind-save").addEventListener("click", () => {
    const text = $("#remind-text").value.trim();
    const time = $("#remind-time").value;
    if (!text || !time) return;
    STATE.reminders.push({ text, time: new Date(time).toISOString() });
    saveData(STORAGE_KEYS.REMINDERS, STATE.reminders);
    $("#remind-text").value = "";
    $("#remind-time").value = "";
    renderReminders();
    addMessage(`⏰ Reminder set: "${text}" at ${new Date(time).toLocaleString()}`, "bot");
  });
  document.addEventListener("click", e => {
    if (e.target.dataset.remind !== undefined) {
      STATE.reminders.splice(parseInt(e.target.dataset.remind), 1);
      saveData(STORAGE_KEYS.REMINDERS, STATE.reminders);
      renderReminders();
      addMessage("🗑️ Reminder removed", "bot");
    }
  });

  // 3. TASKS
  $("#task-save").addEventListener("click", () => {
    const text = $("#task-input").value.trim();
    if (!text) return;
    STATE.tasks.push({ text, done: false, created: new Date().toISOString() });
    saveData(STORAGE_KEYS.TASKS, STATE.tasks);
    $("#task-input").value = "";
    renderTasks();
    addMessage(`✅ Task added: "${text}"`, "bot");
  });
  document.addEventListener("change", e => {
    if (e.target.classList.contains("fc-task-check")) {
      const idx = parseInt(e.target.dataset.task);
      STATE.tasks[idx].done = e.target.checked;
      saveData(STORAGE_KEYS.TASKS, STATE.tasks);
      renderTasks();
    }
  });
  document.addEventListener("click", e => {
    if (e.target.dataset.task !== undefined) {
      STATE.tasks.splice(parseInt(e.target.dataset.task), 1);
      saveData(STORAGE_KEYS.TASKS, STATE.tasks);
      renderTasks();
      addMessage("🗑️ Task removed", "bot");
    }
  });

  // 4. SEARCH
  $("#search-go").addEventListener("click", () => {
    const q = $("#search-input").value.trim();
    const engine = $("#search-engine").value;
    if (!q) return;
    const urls = {
      google: "https://www.google.com/search?q=",
      bing: "https://www.bing.com/search?q=",
      duckduckgo: "https://duckduckgo.com/?q="
    };
    window.open(urls[engine] + encodeURIComponent(q), "_blank");
    addMessage(`🔍 Searching for "${q}" on ${engine}...`, "bot");
  });
  $("#search-input").addEventListener("keydown", e => e.key === "Enter" && $("#search-go").click());

  // 5. SCREENSHOT
  // 5. SCREENSHOT — Updated to use background worker
$("#screenshot-btn").addEventListener("click", async () => {
  const status = $("#screenshot-status");
  status.textContent = "Capturing...";
  
  try {
    // Check if running as proper extension
    if (!(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage)) {
      throw new Error("Not running as Chrome Extension");
    }
    
    // Ask background worker to take screenshot
    const response = await chrome.runtime.sendMessage({ action: "takeScreenshot" });
    
    if (!response || !response.success || !response.dataUrl) {
      throw new Error("No response from background worker");
    }
    
    // Download the image
    const link = document.createElement("a");
    link.href = response.dataUrl;
    link.download = `screenshot-${new Date().toISOString().slice(0,19).replace(/[:T]/g,"-")}.png`;
    link.click();
    
    status.textContent = "✅ Screenshot saved!";
    addMessage("📸 Screenshot captured and downloaded!", "bot");
    
  } catch (err) {
    console.error("Screenshot error:", err);
    status.textContent = "⚠️ Screenshot failed — check extension setup";
    addMessage("❌ Screenshot failed: " + err.message + "<br>Make sure you loaded this as a Chrome Extension!", "bot");
  }
  
  setTimeout(() => status.textContent = "", 4000);
});

  // 6. PASSWORD MANAGER
  $("#pw-save").addEventListener("click", () => {
    const name = $("#pw-name").value.trim();
    const pass = $("#pw-value").value;
    if (!name || !pass) { alert("Fill both fields"); return; }
    STATE.passwords.push({ name, value: btoa(pass), created: new Date().toISOString() });
    saveData(STORAGE_KEYS.PASSWORDS, STATE.passwords);
    $("#pw-name").value = "";
    $("#pw-value").value = "";
    renderPasswords();
    addMessage(`🔐 Password saved for "${name}"`, "bot");
  });
  document.addEventListener("click", e => {
    // Show/Hide password
    if (e.target.dataset.pw !== undefined) {
      const idx = parseInt(e.target.dataset.pw);
      if (e.target.textContent === "👁️ Show") {
        e.target.textContent = atob(STATE.passwords[idx].value);
        e.target.style.maxWidth = "none";
      } else {
        e.target.textContent = "👁️ Show";
      }
    }
    // Delete password
    if (e.target.dataset.pwDel !== undefined) {
      STATE.passwords.splice(parseInt(e.target.dataset.pwDel), 1);
      saveData(STORAGE_KEYS.PASSWORDS, STATE.passwords);
      renderPasswords();
      addMessage("🗑️ Password deleted", "bot");
    }
  });

})();